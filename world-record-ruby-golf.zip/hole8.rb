### HOLE 8 LOVE TEST
def test(s,sb)
  a = s.strip
  b = sb.strip
  n = a.count(b)
  t = s.size + b.size;
  puts t / n;
end
test("stringstriNg","stringstring")
#CHARACTERS 47
