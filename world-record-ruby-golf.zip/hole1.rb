### HOLE 1 ADD ALL ARRAY VARIABLES
def a(a)
  puts(a.reduce {|sum, num| sum + num})
end
a([9,1,2,3,6])
# 33 CHARACTERS
