### HOLE 3 FIZZ BUZZ
def fizzbuzz
  (1..100).each {|i| puts i, puts "fizz" if i%3 == 0; puts "buzz" if i%5 == 0;}
end
fizzbuzz
# 62 CHARACTERS
