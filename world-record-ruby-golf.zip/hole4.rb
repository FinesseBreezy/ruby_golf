### HOLE 4 MULTIPLES UP TO A NUMBER
def multiples(n,c)
  1.upto(c){|i|puts n * i}
end
puts multiples(23, 6)
# 17 CHARACTERS
